package com.example.adityapatell;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {
    private GridView gridView;
    private Button addDataButton;
    private Button deleteDataButton;
    private DatabaseHelper db;
    private ArrayList<String> eventList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        db = new DatabaseHelper(this);
        gridView = findViewById(R.id.gridView);
        addDataButton = findViewById(R.id.btnAddData);
        deleteDataButton = findViewById(R.id.btnDeleteData);

        eventList = new ArrayList<>();
        loadEvents();  // Load events from database and display in GridView

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventList);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(DataDisplayActivity.this, "You clicked: " + eventList.get(position), Toast.LENGTH_SHORT).show();
            }
        });

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                db.addEvent("Event " + (eventList.size() + 1), "Date " + (eventList.size() + 1), "Description here");
                loadEvents();
            }
        });

        deleteDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!eventList.isEmpty()) {
                    int lastId = eventList.size();
                    db.deleteEvent(lastId);
                    loadEvents();  // Reload data after deletion
                }
            }
        });
    }

    private void loadEvents() {
        Cursor cursor = db.getAllEvents();
        eventList.clear();
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String eventName = cursor.getString(cursor.getColumnIndex("event_name"));
            eventList.add(eventName);
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
}
