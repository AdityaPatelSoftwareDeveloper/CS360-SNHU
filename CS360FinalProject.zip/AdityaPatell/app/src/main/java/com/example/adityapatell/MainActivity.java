package com.example.adityapatell;

//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class MainActivity extends AppCompatActivity {
//
//    private EditText editTextUsername, editTextPassword;
//    private Button buttonLogin, buttonCreateAccount;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        // Initialize UI components
//        editTextUsername = findViewById(R.id.editTextUsername);
//        editTextPassword = findViewById(R.id.editTextPassword);
//        buttonLogin = findViewById(R.id.buttonLogin);
//        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
//
//        // Set click listeners
//        buttonLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Handle login button click
//                String username = editTextUsername.getText().toString();
//                String password = editTextPassword.getText().toString();
//
//                // Perform login authentication logic here
//                // For demonstration purposes, display a toast message
//                Toast.makeText(MainActivity.this, "Login clicked with username: " + username + " and password: " + password, Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Handle create account button click
//                // You can navigate to a new screen to create account or perform necessary logic here
//                Toast.makeText(MainActivity.this, "Create Account clicked", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//}
